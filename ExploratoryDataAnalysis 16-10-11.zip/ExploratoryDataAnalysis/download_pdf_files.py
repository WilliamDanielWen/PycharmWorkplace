

import re


import urllib2
def save_pdf_file_bak(pdf_url, filename, folder):
    response = urllib2.urlopen(pdf_url)
    file = open(folder+"/"+filename, 'wb')
    file.write(response.read())
    file.close()
    print "Downloading ",pdf_url," ..."
    print "Rename as ",filename
    print ""

import urllib
def save_pdf_file(pdf_url, filename, folder):
    response = urllib.urlretrieve(pdf_url,folder+"/"+filename)

    print "Downloading ",pdf_url," ..."
    print "Rename as ",filename
    print ""


def get_new_file_name(pdf_url):

    file_name=pdf_url.split("/")[-1]

    #print "changing file name ", file_name, " ..."

    #change the peer name
    file_name=file_name.replace("PeerGroup","Peer")


    date=file_name.split("_")[-1]

    #remove the suffix
    date=date.replace(".pdf","")
    new_date=change_date_format(date)

    new_file_name=file_name.replace(date,new_date)
    return new_file_name
    #print "new name",file_name


def change_date_format(old_format):
    year=old_format[-4:]
    month=old_format.replace(year,"")

    month=month.lower()

    if month == "january" or month == "february" or month == "march" or month=="mar":
        quarter="Quarter1"

    elif month == "april" or month == "may" or month == "june" or month=="jun":
        quarter="Quarter2"

    elif month == "july" or month == "august" or month == "september" or month =="sept" or month=="sep":
        quarter="Quarter3"

    elif month == "october" or month == "november" or month == "december" or month=="dec":
        quarter="Quarter4"

    else:
        #for debugging
        quarter = "UnknownQuarter-"+month

    new_format=year+"_"+quarter
    return new_format





if __name__ == "__main__":
    seed_url = "https://www.ffiec.gov/nicpubweb/content/BHCPRRPT/BHCPR_Peer.htm"
    seed_response=urllib2.urlopen(seed_url,timeout=20)
    source=seed_response.read()
    reletive_urls=re.findall(re.compile(r"<a href=\"(.*?).pdf\">"), source)
    full_url=[]
    for url  in reletive_urls:
        if url.split("_")[-2]=="1":
            #only remain the peer1 data
            full_url.append("https://www.ffiec.gov/nicpubweb/content/BHCPRRPT/"+url+".pdf")

    for url in full_url:
        new_name=get_new_file_name(url)
        save_pdf_file(url, new_name, "downloaded_pdf_files")

    url="https://www.ffiec.gov/nicpubweb/content/BHCPRRPT/REPORTS/BHCPR_PEER/March2016/PeerGroup_1_March2016.pdf"
